编译方式：
1.
>>> cmake .
>>> make
>>> ./main

2.
>>> g++ main.cpp -o main
>>> ./main
